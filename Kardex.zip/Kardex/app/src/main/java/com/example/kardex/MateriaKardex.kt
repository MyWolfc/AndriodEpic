package com.example.kardex

data class MateriaKardex(

    val periodo : String,
    val clave_materia : String,
    val materia : String,
    val calificacion : Int
)
