package com.example.kardex
import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.kardex.databinding.FragmentSecondBinding

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class SecondFragment : Fragment() {

    private var _binding: FragmentSecondBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activityContext = requireActivity()
        binding.btnEliminar.setOnClickListener{
            //Log.d("TAG", "message")

            val periodoExiste = binding.txtPeriodo.text.toString().isEmpty()
            val clave_materiaExiste = binding.txtClaveMateria.text.toString().isEmpty()
            val materiaExiste = binding.txtCalificacion.text.toString().isEmpty()
            val calificacionExiste = binding.txtCalificacion.text.toString().isEmpty()
            if (periodoExiste || clave_materiaExiste || materiaExiste || calificacionExiste)
            {
                Toast.makeText(activityContext, "Por favor, llene todos los campos", Toast.LENGTH_SHORT).show()
            }
            else
            {
                val periodo = binding.txtPeriodo.text.toString()
                val clave_materia = binding.txtClaveMateria.text.toString()
                val materia = binding.txtMateria.text.toString()
                val calificacionText = binding.txtCalificacion.text.toString()
                val calificacion = if (calificacionText.isNotBlank()) calificacionText.toInt() else 0

                val materia_kardex = MateriaKardex(periodo, clave_materia, materia, calificacion)
                val posicionEliminar = Singleton.getItem(materia_kardex)

                val builder = AlertDialog.Builder(activityContext)

                builder.setTitle("Se eliminara el siguiente registro")
                builder.setMessage("Se eliminara este registro. ¿Estás seguro de continuar?")

                builder.setPositiveButton("Aceptar") { dialog, which ->
                    Singleton.removeItem(posicionEliminar)
                    Toast.makeText(activityContext, "Por favor, llene todos los campos", Toast.LENGTH_SHORT).show()
                    findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
                }

                builder.setNegativeButton("Cancelar") { dialog, which ->
                    //val posicion = Singleton.kardex.
                    dialog.dismiss()
                }

                val dialog: AlertDialog = builder.create()
                dialog.show()
            }

        }
        binding.btnGuardarMateriaKardex.setOnClickListener {
            val periodo = binding.txtPeriodo.text.toString()
            val clave_materia = binding.txtClaveMateria.text.toString()
            val materia = binding.txtMateria.text.toString()
            val calificacionText = binding.txtCalificacion.text.toString()
            val calificacion = if (calificacionText.isNotBlank()) calificacionText.toInt() else 0

            val materia_kardex = MateriaKardex(periodo, clave_materia, materia, calificacion)

            Singleton.kardex.add(materia_kardex)

            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }

        arguments?.let { bundle ->
            val periodo = bundle.getString("periodo")
            val clave_materia = bundle.getString("clave_materia")
            val materia = bundle.getString("materia")
            val calificacion = bundle.getInt("calificacion")
            var buscarMaterialKardex = MateriaKardex(periodo.toString(),clave_materia.toString(),materia.toString(),calificacion.toInt())
            val posicion = Singleton.getItem(buscarMaterialKardex)
            Log.d("Posicion por busquedad",posicion.toString())
            binding.txtPeriodo.setText(periodo)
            binding.txtClaveMateria.setText(clave_materia)
            binding.txtMateria.setText(materia)
            binding.txtCalificacion.setText(calificacion.toString())
            }
        }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}